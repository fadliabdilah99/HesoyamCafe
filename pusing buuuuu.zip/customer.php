<div class="col-lg-9  mt-2">
    <div class="card">
        <div class="card-header">
            customer
        </div>
        <div class="card-body">
            <h5 class="card-title">Bagian Honme</h5>
            <p class="card-text">With supporting text below as a natural lead-in to additional content Lorem, ipsum dolor sit amet consectetur adipisicing elit. Placeat nesciunt hic omnis ipsam possimus eos pariatur perferendis error blanditiis aperiam facilis veritatis in odio earum, dignissimos tempora amet eius quae?.</p>
            <a href="#" class="btn btn-primary">Go somewhere</a>
        </div>
    </div>
</div>